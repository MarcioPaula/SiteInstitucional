<html>
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/template.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">

</head>
<body>

<nav>
    <div class="nav-wrapper white" >
        <a href="#" class="brand-logo"><img width="250" src="<?php echo e(asset('images/logo.png')); ?>" alt=""></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down ">
            <li><a href="/">Pagina Inicial</a></li>
            <li><a href="/Solicitar">Solicite um orçamento</a></li>
            <li><a href="/#sobre">Sobre nós</a></li>
        </ul>
    </div>
</nav>

<header>

</header>
<main>
<?php /**PATH C:\Users\marcio.paula\Documents\Projetos\SiteInstitucional\resources\views/_layout/header.blade.php ENDPATH**/ ?>