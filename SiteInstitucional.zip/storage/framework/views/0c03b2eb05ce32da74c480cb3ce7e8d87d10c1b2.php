<?php echo $__env->make('_layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('conteudo'); ?>

<?php echo $__env->make('_layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\marcio.paula\Documents\Projetos\SiteInstitucional\resources\views/_layout/template.blade.php ENDPATH**/ ?>