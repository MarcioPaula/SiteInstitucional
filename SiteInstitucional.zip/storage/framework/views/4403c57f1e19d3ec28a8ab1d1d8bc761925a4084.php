<?php $__env->startSection('titulo', 'Página Inicial'); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="parallax-container" id="parallax1">
        <div class="parallax"><img src="<?php echo e(asset('images/parallax1.jpg')); ?>"></div>
    </div>

            <h3 class="center">Para você</h3>

            <div class="row" id="cards">

                <div class="col s12 m3 offset-m1">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo e(asset('images/solicite.jpg')); ?>">
                            <span class="card-title black">Solicite o seu site</span>
                        </div>
                        <div class="card-content">
                            <p>Solicite o seu site personalizado para divulgar a sua marca e atrair mais clientes</p>
                        </div>
                        <div class="card-action">
                            <a href="/Solicitar">Solicitar site</a>
                        </div>
                    </div>
                </div>
               <!-- <div class="col s12 m3">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo e(asset('images/parceiros.jpg')); ?>">
                            <span class="card-title black">Parceiros</span>
                        </div>
                        <div class="card-content">
                            <p>Veja os nossos principais parceiros para quem criamos sites.</p>
                            <br>
                        </div>
                        <div class="card-action">
                            <a href="#parceiros">Parceiros</a>
                        </div>
                    </div>
                </div> -->
                <div class="col s12 m3">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo e(asset('images/sobre.jpg')); ?>">
                            <span class="card-title  black">Sobre nós</span>
                        </div>
                        <div class="card-content">
                            <p>Conheça um pouco sobre a vortex sites e solicite o seu proprio site</p>
                            <br>
                        </div>
                        <div class="card-action">
                            <a href="#sobre">Sobre nós</a>
                        </div>
                    </div>
                </div>
            </div>

    <div class="parallax-container" id="parallax2">
        <div class="parallax"><img src="<?php echo e(asset('images/parallax1.jpg')); ?>"></div>
    </div>

   <!-- <div id="parceiros">
        <h3 class="center">Nossos parceiros</h3>
        <div class="row center ">
            <div class="col m8 offset-m2 ">
                <img width="150" src="<?php echo e(asset('images/logo_senac_default.png')); ?>" alt=""> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                <img width="150" src="<?php echo e(asset('images/logo-ufenesp.png')); ?>" alt=""> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
                <img class="grey" width="150" src="<?php echo e(asset('images/swfast-logo.png')); ?>" alt="">

            </div>
        </div>
    </div> -->

    <div class="parallax-container" id="parallax2">
        <div class="parallax"><img src="<?php echo e(asset('images/parallax1.jpg')); ?>"></div>
    </div>


    <div id="sobre">
        <h3 class="center">Sobre nós</h3>
        <div class="row center">
            <div class="col m4 offset-m4">
                <p>A Empresa Vortex, é nova no mercado criada para ajudar as pequenas empresas e empresarios a criar seu primeiro site institucional. Temos em nossa visão crescimento, para um dia se tornar uma grande empresa de desenvolvimento de softwares e sites</p>

                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
            </div>
        </div>
    </div>

    <div id="parallax1" class="parallax-container">
        <div class="parallax"><img src="<?php echo e(asset('images/parallax1.jpg')); ?>"></div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\marcio.paula\Documents\Projetos\SiteInstitucional\resources\views/home.blade.php ENDPATH**/ ?>